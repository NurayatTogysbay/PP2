#operators

print((6 + 3) - (6 + 3))

# Multiplication, Division, Floor, Moduls
print(4 * 3, 10 / 2, 10 // 3, 10 % 3)

# Addition, Subtraction, Bitwise shifts
print(7 + 3, 7 - 3, 4 << 1, 4 >> 1)

# Bitwise AND, XOR, OR
print(5 & 3, 5 ^ 3, 5 | 3)
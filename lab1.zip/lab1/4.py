#Comments

#This is a comment
print("Hello, World!")

"""
This is a comment
written in 
more than just one line
"""
print("Hello, World!")
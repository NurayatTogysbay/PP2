#Get Started
import sys

print(sys.version)
#Variables

x = 5
y = "John"
print(x)
print(y)

x, y, z = "Orange", "Banana", "Cherry"
print(x)
print(y)
print(z)


x = "awesome"

def myfunc():
  print("Python is " + x)

myfunc()
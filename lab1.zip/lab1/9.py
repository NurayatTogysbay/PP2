#Strings

b = "Hello, World!"
print(b[:5])

a = "Hello, World!"
print(a.lower())

a = "Hello, World!"
print(a.upper())

a = " Hello, World! "
print(a.strip()) # returns "Hello, World!"


a = "Hello"
b = "World"
c = a + b
print(c)

age = 36
txt = f"My name is John, I am {age}"
print(txt)
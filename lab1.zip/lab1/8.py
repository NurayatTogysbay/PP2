#Castling

x = int(1)   # x will be 1
y = int(2.8) # y will be 2
z = int("3") # z will be 3

print(f"{x}\n{y}\n{z}")
import re


txt = 'wkgmwrgiuageoigjoijwfb'
x = re.search('a.*b$', txt)
print(x)

